# AI-Powered Lofi Music Remix System 🎶

A project that remixes lofi music based on real-time emotional input. Uses emotion detection to generate personalized audio experiences.

## 🚀 Features
- Emotion-to-sound mapping using Python
- Integrated with Audacity for remix generation
- Personalized music for productivity and mood

## 🧠 Tech Stack
- Python
- Emotion Detection APIs
- Audacity

## 📂 Folder Structure
- `emotion_detection/`: Scripts for recognizing emotion
- `remixer/`: Audio remix logic using Audacity

## 👩‍💻 Author
[Dhani Sharma](https://github.com/dhaniii16)
