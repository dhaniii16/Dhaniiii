# Resume & Portfolio Builder Tool 📝⚙️

An Angular + Firebase-based platform for building and downloading smart resumes.

## 🌟 Highlights
- Integrated Microsoft Graph API for Word export
- Secure user-authentication with Firebase
- Dynamic layout generation

## 🔧 Tech Stack
- Angular, Node.js
- Firebase Realtime DB
- Microsoft Graph API

## 📁 Structure
- `frontend/`: Angular UI
- `backend/`: Node.js functions

## 👩‍💻 Author
[Dhani Sharma](https://github.com/dhaniii16)
